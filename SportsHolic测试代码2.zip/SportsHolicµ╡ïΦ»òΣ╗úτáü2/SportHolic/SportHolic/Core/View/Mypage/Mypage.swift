//
//  Mypage.swift
//  Sports_Holic
//
//  Created by 杨航 on 2024/9/28.
//

import SwiftUI

struct Mypage: View {
    @EnvironmentObject var viewModel: AuthModel
    var body: some View {
        
        //if let user = viewModel.currentUser{
            NavigationStack {
                ZStack{
                    Color.green
                        .ignoresSafeArea()
                    VStack{
                        ScrollView{
                            
                            VStack{
                                HStack{
                                    Spacer()
                                    Text("Sports Holic")
                                        .font(.largeTitle)
                                        .fontWeight(.thin)
                                        .multilineTextAlignment(.leading)
                                    
                                    Spacer()
                                    
                                    Image(systemName: "person")
                                    Text("My Page")
                                        .fontWeight(.light)
                                    
                                    Spacer()
                                    
                                }
                                
                            }  // Vstack  Title
                            
                            Divider()
                            
                            VStack(alignment: .leading,spacing: 20.0) {         //用于生成框，竖向排列
                    
                                Text("My information")
                                    .font(.body)
                                    .foregroundColor(Color.white)
                                
                                HStack{
                                    Spacer()
                                    
                                    Text("user.initials")
                                        .font(.title)
                                        .fontWeight(.semibold)
                                        .foregroundColor(.white)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: 100,height: 100)
                                        .background(Color(.systemGray3))
                                        .clipShape(Circle())
                                    Spacer()
                                }
                                
                                
                                
                                HStack{
                //打印使用过的ID
                                    VStack{
                                        Text("user.fullname")
                                            .font(.title)
                                            .fontWeight(.thin)
                                            .foregroundColor(Color.white)
                                        
                                        
                                        HStack{
                                            Image(systemName:"gear")
                                            Text("user.email")
                                                .font(.title)
                                                .fontWeight(.thin)
                                                .foregroundColor(Color.white)
                                        }
                                    }
                                    
                                    
                                    
                                    Spacer()
                                    
                                    VStack{
                                        HStack{
                                            Image(systemName:"heart.circle.fill")
                                            Text("user.team")
                                                .fontWeight(.bold)
                                                .foregroundColor(Color.white)
                                        }
                                        
                                        
                                    }
                                }
                            }
                            .padding()
                            .background(Rectangle()         //创造一个巨型用于单独赋值
                                .foregroundColor(.blue)
                                .cornerRadius(20.0)
                                .shadow(radius: 20))
                            .padding()
                            
                            
                            Section("Account"){
                                Button{
                                    viewModel.signOut()
                                }label: {
                                    HStack{
                                        Image(systemName:"heart.circle.fill")
                                        Text("Log Out")
                                            .fontWeight(.bold)
                                            .foregroundColor(Color.white)
                                    }
                                }
                            }
                            
                            
                        }  //ScrollView
                        
                        Spacer()
                        
                        
                //底部导航
//                        HStack {
//                            NavigationLink(destination: Home()) {
//                                VStack {
//                                    Image(systemName: "house")
//                                    Text("Home")
//                                }
//                            }
//                            Spacer()
//                            NavigationLink(destination: News()){
//                                VStack {
//                                    Image(systemName: "newspaper")
//                                    Text("News")
//                                }
//                            }
//                            Spacer()
//                            NavigationLink(destination: Schedule()){
//                                VStack {
//                                    Image(systemName: "timer")
//                                    Text("Schedule")
//                                }
//                            }
//
//                            Spacer()
//                            NavigationLink(destination: Analysis()){
//                                VStack {
//                                    Image(systemName: "x.squareroot")
//                                    Text("Analysis")
//                                }
//                            }
//
//                            Spacer()
//                            NavigationLink(destination: Mypage()){
//                                VStack {
//                                    Image(systemName: "person")
//                                    Text("Me")
//                                }
//                            }
//
//
//                        }
//                        .padding()
//                        .background(Color.black)
//                        .foregroundColor(.white)
//                        .frame(maxWidth: .infinity)
                    }  //Zstack
                    .ignoresSafeArea(.keyboard, edges: .bottom)
                

                    }
                    
                
            }  //NavigationStack
            .navigationBarBackButtonHidden(true)
            
            
       }
    }
//}

struct Mypage_Previews: PreviewProvider {
    static var previews: some View {
        Mypage()
    }
}
