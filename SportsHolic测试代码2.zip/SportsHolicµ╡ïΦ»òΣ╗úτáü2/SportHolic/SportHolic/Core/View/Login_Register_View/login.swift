//
//  login.swift
//  Sports_Holic
//
//  Created by 杨航 on 2024/9/28.
//

import SwiftUI

struct login: View {
    @State private var email = ""
    @State private var Password = ""
    @EnvironmentObject var viewModel : AuthModel
    
    var body: some View {
        
        NavigationStack {
            ZStack{
                Color.green
                    .ignoresSafeArea()
                
                VStack{
                    Spacer()

                    Text("Sports Holic")
                        .font(.largeTitle)
                        .bold()
                        .padding()
                    
                    Spacer()

                    Text("Login")
                        .font(.largeTitle)
                    
                    TextField("Email", text: $email)
                        .padding(.all)
                        .frame(width: 300, height: 50)
                        .background(Color.white)
                        .autocapitalization(.none)
                        .cornerRadius(15)
                    TextField("Password", text: $Password)
                        .padding(.all)
                        .frame(width: 300, height: 50)
                        .background(Color.white)
                        .cornerRadius(15)
                    
                    
        //登陆 跳转到Mypage
                    Button{
                        Task{
                            print("Start login...")
                            try await viewModel.signIn(withEmail: email, password: Password)
                        }
                        
                    }label: {
                        HStack{
                            Text("SIGIN IN")
                                .fontWeight(.semibold)
                            Image(systemName: "arrow.right")
                        }
                        .bold()
                        .foregroundColor(.white)
                        .frame(width: 300, height: 50)
                        .background(Color.black)
                        .cornerRadius(15)
                        .padding()
                    }
                    .padding(.all)
                    .disabled(formIsValid)
                    .opacity(formIsValid ? 1.0 :0.5)
                    
                    Spacer()
            
                    
        //跳转到注册
                    NavigationLink{
                        Register()
                            .navigationBarBackButtonHidden(true)
                    }label: {
                        HStack{
                            Text("Don't have an account? ")
                                .foregroundColor(Color.black)
                            Text("Sign up!")
                                .foregroundColor(Color.white)
                                .fontWeight(.bold)
                        }
                        .font(.system(size: 14))
                    }
                    
                }

            }
        }
        
        
    }
}

extension login:AuthenticationFormProtocol{
    var formIsValid: Bool{
        return !email.isEmpty
        && email.contains("@")
        && !Password.isEmpty
        && Password.count > 5
    }
}

struct login_Previews: PreviewProvider {
    static var previews: some View {
        login()
    }
}
