//
//  Home.swift
//  Sports_Holic
//
//  Created by 杨航 on 2024/9/28.
//

import SwiftUI

struct Home: View {
        
        var body: some View {
            
            NavigationStack {
                ZStack{
                    Color.green
                        .ignoresSafeArea()
                    VStack{
                        ScrollView{
                            
                            VStack{
                                HStack{
                                    Spacer()
                                    Text("Sports Holic")
                                        .font(.largeTitle)
                                        .fontWeight(.thin)
                                        .multilineTextAlignment(.leading)
                                    
                                    Spacer()
                                    
                                    Text("K리그의 모든 것")
                                        .fontWeight(.light)
                                    
                                    Spacer()
                                    
                                }
                                
                            }  // Vstack
                            
                            Text("\n")
                            
                            NavigationLink(destination: login()){
                                Text("Login & Register")
                                    .bold()
                                    .foregroundColor(.white)
                                    .frame(width: 300, height: 50)
                                    .background(Color.black)
                                    .cornerRadius(15)
                            }
                            .padding()
                            
                            
                            HStack{
                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                            }


                            HStack{
                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                            }

                            HStack{
                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                            }
                            HStack{
                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                            }
                        
                            
                            
                            
                        }  //ScrollView
                        
                        Spacer()
                        
                        HStack {
                            NavigationLink(destination: Home()) {
                                VStack {
                                    Image(systemName: "house")
                                    Text("Home")
                                }
                            }
                            Spacer()
                            NavigationLink(destination: News()){
                                VStack {
                                    Image(systemName: "newspaper")
                                    Text("News")
                                }
                            }
                            Spacer()
                            NavigationLink(destination: Schedule()){
                                VStack {
                                    Image(systemName: "timer")
                                    Text("Schedule")
                                }
                            }
                            
                            Spacer()
                            NavigationLink(destination: Analysis()){
                                VStack {
                                    Image(systemName: "x.squareroot")
                                    Text("Analysis")
                                }
                            }
                           
                            Spacer()
                            NavigationLink(destination: Mypage()){
                                VStack {
                                    Image(systemName: "person")
                                    Text("Me")
                                }
                            }
                           
                            
                        }
                        .padding()
                        .background(Color.black)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        
                    }  //Zstack
                    .ignoresSafeArea(.keyboard, edges: .bottom)
                

                    }
                    
                
            }  //NavigationStack
            .navigationBarBackButtonHidden(true)
        }  //body View
        
    }



struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
