//
//  Schedule.swift
//  Sports_Holic
//
//  Created by 杨航 on 2024/9/28.
//

import SwiftUI

struct Schedule: View {
    var body: some View {
        NavigationStack {
            ZStack{
                Color.green
                    .ignoresSafeArea()
                VStack{
                    ScrollView{
                        VStack{
                            HStack{
                                Spacer()
                                Text("Sports Holic\n \nSchedule")
                                    .font(.largeTitle)
                                    .fontWeight(.black)
                                    .multilineTextAlignment(.leading)


                                Spacer()

                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)

                                Spacer()
                            }

                            HStack{
                                Spacer()
                                Button("News"){

                                }
                                .bold()
                                .foregroundColor(.white)
                                .frame(width: 100, height: 50)
                                .background(Color.black)
                                .cornerRadius(15)
                                Spacer()
                                Button("Schedule"){

                                }
                                .bold()
                                .foregroundColor(.white)
                                .frame(width: 100, height: 50)
                                .background(Color.black)
                                .cornerRadius(15)
                                Spacer()
                                Button("Analysis"){

                                }
                                .bold()
                                .foregroundColor(.white)
                                .frame(width: 100, height: 50)
                                .background(Color.black)
                                .cornerRadius(15)



                                Spacer()
                            }

                            Spacer()

                            Text("\n===========================\n")
                            Text("Calender")
                                .font(.title)
                                .fontWeight(.light)
                                .foregroundColor(Color.red)

                            HStack{
                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                                Image("vs")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                            }

                            Text("< Date of Game >")
                                .font(.title2)
                                .fontWeight(.light)
                            Text("n.n")
                                .font(.title2)
                                .fontWeight(.light)

        //                    Spacer()

                            Button("예매하러 가기!"){

                            }
                            .bold()
                            .foregroundColor(.white)
                            .frame(width: 150, height: 50)
                            .background(Color.black)
                            .cornerRadius(15)



                            Button(action: {

                            }) {
                                Text("시청하러 가기!")
                                    .bold()
                                    .foregroundColor(.white)
                                    .frame(width: 150, height: 50)
                                    .background(Color.black)
                                    .cornerRadius(15)
                            }





                        }
                      
                        
                    }  //ScrollView
                    
                    Spacer()
                    
                    HStack {
                        NavigationLink(destination: Home()) {
                            VStack {
                                Image(systemName: "house")
                                Text("Home")
                            }
                        }
                        Spacer()
                        NavigationLink(destination: News()){
                            VStack {
                                Image(systemName: "newspaper")
                                Text("News")
                            }
                        }
                        Spacer()
                        NavigationLink(destination: Schedule()){
                            VStack {
                                Image(systemName: "timer")
                                Text("Schedule")
                            }
                        }
                        
                        Spacer()
                        NavigationLink(destination: Analysis()){
                            VStack {
                                Image(systemName: "x.squareroot")
                                Text("Analysis")
                            }
                        }
                       
                        Spacer()
                        NavigationLink(destination: Mypage()){
                            VStack {
                                Image(systemName: "person")
                                Text("Me")
                            }
                        }
                       
                        
                    }
                    .padding()
                    .background(Color.black)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    
                }  //Zstack
                .ignoresSafeArea(.keyboard, edges: .bottom)
            

                }
                
            
        }  //NavigationStack
        .navigationBarBackButtonHidden(true)

    }
}

struct Schedule_Previews: PreviewProvider {
    static var previews: some View {
        Schedule()
    }
}
