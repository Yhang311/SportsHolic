//
//  User.swift
//  Sports_Holic
//
//  Created by 杨航 on 2024/9/28.
//

import Foundation


struct User: Identifiable,Codable{
    let id: String
    let fullname: String
    let email: String
    let team: String
    
    var initials:String{
        let formatter = PersonNameComponentsFormatter()
        if let components = formatter.personNameComponents(from: fullname){
            formatter.style = .abbreviated
            return formatter.string(from: components)
        }
        
        return ""
    }
}


extension User{
    static var User1 = User(id: NSUUID().uuidString, fullname: "User1", email: "test@gmail.com", team: "team_A")
    
}
