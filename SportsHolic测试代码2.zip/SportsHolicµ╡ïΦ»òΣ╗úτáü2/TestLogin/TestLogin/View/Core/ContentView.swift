//
//  ContentView.swift
//  TestLogin
//
//  Created by 杨航 on 2024/9/29.
//

import SwiftUI


struct ContentView: View {
    var body: some View {
        TabView {
//            Home()
//            .tabItem { // 第一个标签
//                Label("Home", systemImage: "house")
//            }
           News()
                .tabItem { // 第二个标签
                    Label("뉴스", systemImage: "newspaper")
                }
            Schedule()
                 .tabItem { // 第二个标签
                     Label("일정", systemImage: "timer")
                 }
            Analysis()
                 .tabItem { // 第二个标签
                     Label("분석", systemImage: "timer")
                 }
            Prediction()
                 .tabItem { // 第二个标签
                     Label("예측", systemImage: "timer")
                 }
            Mypage()
                 .tabItem { // 第二个标签
                     Label("Mypage", systemImage: "person")
                 }
            
        }
        .navigationBarBackButtonHidden(true)
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
