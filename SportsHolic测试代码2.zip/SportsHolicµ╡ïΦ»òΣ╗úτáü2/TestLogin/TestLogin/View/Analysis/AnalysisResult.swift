//
//  AnalysisResult.swift
//  Sports_Holic
//
//  Created by 杨航 on 2024/9/28.
//

import SwiftUI

struct AnalysisResult: View {
    let dataPoints: [CGFloat] = [50, 100, 150, 200, 250]

    var body: some View {
        
        NavigationStack {
            ScrollView{
                VStack{
                    HStack{
                        Spacer()
                        Text("Sports Holic\n \nAnalysis")
                            .font(.largeTitle)
                            .fontWeight(.black)
                            .multilineTextAlignment(.leading)
                        Spacer()
                        Image("team1")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                        Spacer()
                    }

                    
                    Divider()
                    
                    VStack(alignment: .leading){
                        Text("승리       NNN")
                            .font(.headline)
                            .bold()
                        Text("패배")
                            .font(.headline)
                            .bold()
                        Text("무승부")
                            .font(.headline)
                            .bold()
                        Text("승률")
                            .font(.headline)
                            .bold()
                        Text("승점")
                            .font(.headline)
                            .bold()
                        Text("볼 범유율")
                            .font(.headline)
                            .bold()
                    }
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    
                    Divider()
                    
                    Text("< 결과 >")
                        .bold()
                        .font(.title)
                    VStack{
                        // Y轴的最大值
                        let maxValue = dataPoints.max() ?? 1
                        
                        // 绘制柱状图
                        HStack(alignment: .bottom, spacing: 10) {
                            ForEach(0..<dataPoints.count, id: \.self) { index in
                                VStack {
                                    Rectangle()
                                        .fill(Color.blue)
                                        .frame(width: 50, height: dataPoints[index] / maxValue * 250) // 归一化高度
                                    Text("\(Int(dataPoints[index]))") // 显示数据值
                                        .font(.caption)
                                }
                            }
                        }
                        .padding()
                        .border(Color.black) // 为图表添加边框
                    }
                .padding()
                }
            }  //ScrollView
        }
        .ignoresSafeArea(.keyboard, edges: .bottom)
    

        }
        
    
}




struct AnalysisResult_Previews: PreviewProvider {
    static var previews: some View {
        AnalysisResult()
    }
}
