//
//  Analysis.swift
//  Sports_Holic
//
//  Created by 杨航 on 2024/9/28.
//

import SwiftUI

struct Analysis: View {
    
    @State var Month  = ""
    
    var body: some View {
        
        NavigationStack {
            ScrollView{
                VStack{
                    HStack{
                        Spacer()
                        Text("Sports Holic\n \nAnalysis")
                            .font(.largeTitle)
                            .fontWeight(.black)
                            .multilineTextAlignment(.leading)


                        Spacer()

                        Image("team1")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)

                        Spacer()
                    }
                    
                    Divider()
                    
                    Text("< 몇개월치 분석을 보시겠습니다? >")
                        .font(.title2)
                        .fontWeight(.bold)

                    HStack{
                        TextField("input the month", text: $Month)
                            .padding(.all)
                            .frame(width: 200, height: 50)
                            .background(Color.white)
                            .cornerRadius(15)
                        Text("개월")
                            .font(.footnote)
                            .fontWeight(.light)
                    }
                    
                    Text("상대팀")
                    .bold()
                    .foregroundColor(.white)
                    .frame(width: 230, height: 50)
                    .background(Color.gray)
                    .cornerRadius(15)
                    
                    Text("\n")
                    
                    NavigationLink{
                        AnalysisResult()
                    }label: {
                        Button("분석"){

                        }
                        .bold()
                        .foregroundColor(.white)
                        .frame(width: 230, height: 50)
                        .background(Color.black)
                        .cornerRadius(15)
                    }
                    

                }
                
                
            }  //ScrollView

        }  //Zstack
        .ignoresSafeArea(.keyboard, edges: .bottom)
    

        }
}



struct Analysis_Previews: PreviewProvider {
    static var previews: some View {
        Analysis()
    }
}
