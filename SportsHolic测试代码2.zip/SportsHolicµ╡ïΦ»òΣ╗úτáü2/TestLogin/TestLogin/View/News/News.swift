//
//  News.swift
//  TestLogin
//
//  Created by 张菀绮 on 10/1/24.
//

import SwiftUI

struct News: View {
    var body: some View {
        NavigationStack {
            ScrollView{
                VStack{
                    HStack{
                        Spacer()
                        Text("Sports Holic\n \nNEWS")
                            .font(.largeTitle)
                            .fontWeight(.black)
                            .multilineTextAlignment(.leading)
                        Spacer()
                        Image("team1")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                        Spacer()
                    }
                    
                    Divider()
                    
                    VStack{
                        Text("Hot KeyWord")
                            .font(.title)
                            .bold()
                            .foregroundColor(Color.red)
                        Text("1.XXXXXXXXX")
                        Text("2.XXXXXXXXX")
                        Text("3.XXXXXXXXX")
                    }

                    Spacer()

                    Divider()
                    Spacer()

                    Text("NEWS")
                        .font(.title)
                        .bold()
                        .foregroundColor(Color.red)
                    Image("new1")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(.all)
                    
                    NavigationLink{
                        
                    }label: {
                        Text("XXXXXX   &&댓글하면 Click")
                    }

                }
                
            }  //ScrollView
                    
                    Spacer()
                    
                }
                .ignoresSafeArea(.keyboard, edges: .bottom)
            

                }
    }


struct News_Previews: PreviewProvider {
    static var previews: some View {
        News()
    }
}
