//
//  Setting.swift
//  TestLogin
//
//  Created by 杨航 on 2024/9/30.
//

import SwiftUI

struct Setting: View {
    @State private var fullName:String = ""
    @State private var supportedTeam:String = ""
    @State private var password:String = ""
    
    var body: some View {
        VStack{
            HStack{
                Spacer()
                Text("Sports Holic")
                    .font(.largeTitle)
                    .fontWeight(.thin)
                    .multilineTextAlignment(.leading)
                Spacer()
                Image(systemName: "person")
                Text("My Page")
                    .fontWeight(.light)
                Spacer()
            }
            
            Text("SettingPage")
            LoginBlockfunc(title: "change name", text: $fullName)
            LoginBlockfunc(title: "change password", text: $password)
            LoginBlockfunc(title: "change supportedTeam", text: $supportedTeam)
            
            Button(action: {
                //实现修改信息
            }) {
                Text("Reset")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            
        }
    }
}

func ChangeSet(){
    
}

struct Setting_Previews: PreviewProvider {
    static var previews: some View {
        Setting()
    }
}
