import SwiftUI
import Firebase
import FirebaseFirestore

struct Mypage: View {
    @State private var user: User?
    @State private var errorMessage: String = ""

    var body: some View {
        NavigationStack{
            VStack {
                if let user = user {
                    // 抬头部分
                    HStack{
                        Spacer()
                        Text("Sports Holic")
                            .font(.largeTitle)
                            .fontWeight(.thin)
                            .multilineTextAlignment(.leading)
                        Spacer()
                        Image(systemName: "person")
                        Text("My Page")
                            .fontWeight(.light)
                        Spacer()
                    }
                    
                    //卡片信息
                    VStack(alignment: .leading,spacing: 20.0) {         //用于生成框，竖向排列
                        Text("Mypage")
                            .font(.body)
                            .foregroundColor(Color.white)
                        
                        HStack{
                            Spacer()
                            Text(user.fullName)
                                .font(.title)
                                .fontWeight(.semibold)
                                .foregroundColor(.white)
                                .multilineTextAlignment(.leading)
                                .frame(width: 100,height: 100)
                                .background(Color(.systemGray3))
                                .clipShape(Circle())
                            Spacer()
                        }
                        
                        //打印使用过的ID
                        //卡片信息内容：姓名 email 支持球队
                        VStack(alignment: .leading){
                            HStack{
                                Image(systemName: "person")
                                Text(user.fullName)
                                    .font(.title)
                                    .fontWeight(.thin)
                                    .foregroundColor(Color.white)
                            }
                            HStack{
                                Image(systemName:"envelope")
                                Text(user.email)
                                    .font(.title)
                                    .fontWeight(.thin)
                                    .foregroundColor(Color.white)
                            }
                            HStack{
                                Image(systemName:"paperplane")
                                Text(user.supportedTeam)
                                    .font(.title)
                                    .fontWeight(.thin)
                                    .foregroundColor(Color.white)
                            }
                        }
                        
                    }
                    .padding()
                    .background(Rectangle()         //创造一个巨型用于单独赋值
                        .foregroundColor(.blue)
                        .cornerRadius(20.0)
                        .shadow(radius: 20))
                    .padding()
                    
                    Divider()
                    
                    //Setting 设置
                    NavigationLink{
                        Setting()
                    }label: {
                        Image(systemName:"gear")
                        Text("Setting")
                            .bold()
                    }
                    
                } else {
                    Text("Login please!!")
                    
                }
            }
            .onAppear(perform: loadUserData)
        }
    }
    
    
    func loadUserData() {
        let db = Firestore.firestore()
        if let email = Auth.auth().currentUser?.email {
            print("Current user email: \(email)") // 调试信息
            db.collection("users").document(email).getDocument { document, error in
                if let document = document, document.exists {
                    let data = document.data()
                    print("User data: \(String(describing: data))") // 打印获取到的数据
                    user = User(
                        email: email,
                        password: "", // 密码通常不需要存储
                        fullName: data?["fullName"] as? String ?? "",
                        supportedTeam: data?["supportedTeam"] as? String ?? ""
                    )
                } else {
                    errorMessage = error?.localizedDescription ?? "User data not found"
                    print("Error loading user data: \(errorMessage)") // 调试信息
                }
            }
        }
    }
}

struct Mypage_Previews: PreviewProvider {
    static var previews: some View {
        Mypage() // 预览时不需要传递 user
    }
}
