//
//  Schedule.swift
//  Sports_Holic
//
//  Created by 杨航 on 2024/9/28.
//

import SwiftUI

struct Schedule: View {
    var body: some View {
        NavigationStack {
            ScrollView{
                VStack{
                    HStack{
                        Spacer()
                        Text("Sports Holic\n \nSchedule")
                            .font(.largeTitle)
                            .fontWeight(.black)
                            .multilineTextAlignment(.leading)
                        Spacer()
                        Image("team1")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                        Spacer()
                    }

                    Divider()
                    
                    Text("Calender")
                        .font(.title)
                        .bold()
                        .fontWeight(.light)
                        .foregroundColor(Color.red)

                    HStack{
                        Image("team1")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                        Image("vs")
                            .resizable()
                            .background(Color.gray)
                            .aspectRatio(contentMode: .fit)
                            .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                        Image("team1")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                    }

                    Button("일정 선택"){

                    }
                    .bold()
                    .foregroundColor(.white)
                    .frame(width: 150, height: 50)
                    .background(Color.black)
                    .cornerRadius(15)
                    
                    Text("< Date of Game >")
                        .font(.title2)
                        .bold()
                        .fontWeight(.light)
                    Text("n.n")
                        .font(.title2)
                        .fontWeight(.light)

                    Button("예매하러 가기!"){

                    }
                    .bold()
                    .foregroundColor(.white)
                    .frame(width: 150, height: 50)
                    .background(Color.black)
                    .cornerRadius(15)

                    Button(action: {

                    }) {
                        Text("시청하러 가기!")
                            .bold()
                            .foregroundColor(.white)
                            .frame(width: 150, height: 50)
                            .background(Color.black)
                            .cornerRadius(15)
                    }

                }
                      
                        
                    }//ScrollView
                    
                    Spacer()
                    
                }  //Zstack
                .ignoresSafeArea(.keyboard, edges: .bottom)
            
        }  //NavigationStack

}

struct Schedule_Previews: PreviewProvider {
    static var previews: some View {
        Schedule()
    }
}
