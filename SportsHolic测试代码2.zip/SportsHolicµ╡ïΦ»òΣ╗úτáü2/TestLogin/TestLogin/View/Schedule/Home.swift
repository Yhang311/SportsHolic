//
//  Home.swift
//  Sports_Holic
//
//  Created by 杨航 on 2024/9/28.
//

import SwiftUI

struct Home: View {
    
    var body: some View {
        
        NavigationStack {
            ZStack{
                
                VStack{
                    ScrollView{
                        HStack{
                            Spacer()
                            Text("Sports Holic")
                                .font(.largeTitle)
                                .fontWeight(.thin)
                                .multilineTextAlignment(.leading)
                            Spacer()
                            Text( "K리그의 모든 것")
                                .fontWeight(.light)
                            Spacer()
                        }

                        Divider()
                    
                        HStack{
                            Image("team1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                            Image("team1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                            Image("team1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                        }
                        HStack{
                            Image("team1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                            Image("team1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                            Image("team1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                        }
                        HStack{
                            Image("team1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                            Image("team1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                            Image("team1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                        }
                        HStack{
                            Image("team1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                            Image("team1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                            Image("team1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                        }
                    }  //ScrollView
                    
                    Spacer()
                }
                .padding()
                .foregroundColor(.black)
                .frame(maxWidth: .infinity)
                
            }  //Zstack
            .ignoresSafeArea(.keyboard, edges: .bottom)
            
            
        }  //NavigationStack
    }  //body View
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
