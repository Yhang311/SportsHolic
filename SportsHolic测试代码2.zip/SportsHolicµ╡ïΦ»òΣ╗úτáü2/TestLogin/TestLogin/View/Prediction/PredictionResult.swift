//
//  PredictionResult.swift
//  TestLogin
//
//  Created by 张菀绮 on 10/2/24.
//

import SwiftUI

struct PredictionResult: View {
    var body: some View {
        VStack{
            VStack{
                HStack{
                    Spacer()
                    Text("Sports Holic\n \nPrediction")
                        .font(.largeTitle)
                        .fontWeight(.black)
                        .multilineTextAlignment(.leading)
                    Spacer()
                    Image("team1")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                    Spacer()
                }
                
                Divider()
                
                HStack{
                    Image("team1")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                    Image("vs")
                        .resizable()
                        .background(Color.gray)
                        .aspectRatio(contentMode: .fit)
                        .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                    Image("team1")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                }
                
                Divider()
                
                HStack{
                    Text("승리")
                        .font(.title)
                        .bold()
                        .background(.red)
                    Text("패배")
                        .font(.title)
                        .bold()
                        .background(.blue)
                    Text("무승부")
                        .font(.title)
                        .bold()
                        .background(.gray)
                }
                
                Divider()
                
                Text("< 예측 결과 칸에만 샛입힘 >")
                    .font(.title2)
                    .fontWeight(.bold)
                
                Divider()
                
                Text("예측 결과      NN%")
                    .bold()
                    .foregroundColor(.white)
                    .frame(width: 230, height: 50)
                    .background(Color.black)
                    .cornerRadius(15)
            }
            
        }
    }
}
    
    struct PredictionResult_Previews: PreviewProvider {
        static var previews: some View {
            PredictionResult()
        }
    }

