//
//  Prediction.swift
//  TestLogin
//
//  Created by 张菀绮 on 10/2/24.
//

import SwiftUI

struct Prediction: View {
    
    @State var Month  = ""
    
    var body: some View {
        
        NavigationStack {
            ScrollView{
                VStack{
                    HStack{
                        Spacer()
                        Text("Sports Holic\n \nPrediction")
                            .font(.largeTitle)
                            .fontWeight(.black)
                            .multilineTextAlignment(.leading)
                        Spacer()
                        Image("team1")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                        Spacer()
                    }

                    Divider()
                
                    Text("< 상대팀 고르세요? >")
                        .font(.title2)
                        .fontWeight(.bold)

                    

                    Button("상대팀"){

                    }
                    .bold()
                    .foregroundColor(.white)
                    .frame(width: 230, height: 50)
                    .background(Color.gray)
                    .cornerRadius(15)

                    Text("\n")

                    NavigationLink{
                        PredictionResult()
                    }label: {
                        Text("에약하기")
                            .bold()
                            .foregroundColor(.white)
                            .frame(width: 230, height: 50)
                            .background(Color.black)
                            .cornerRadius(15)
                    }
                    

                }
            }  //ScrollView
        }
        .ignoresSafeArea(.keyboard, edges: .bottom)
    

        }
        
    
}




struct Prediction_Previews: PreviewProvider {
    static var previews: some View {
        Prediction()
    }
}
