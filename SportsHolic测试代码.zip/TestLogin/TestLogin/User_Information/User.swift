//
//  User.swift
//  TestLogin
//
//  Created by 杨航 on 2024/9/29.
//

import Foundation

struct User {
    var email: String
    var password: String
    var fullName: String
    var supportedTeam: String
}
