//
//  TestLoginApp.swift
//  TestLogin
//
//  Created by 杨航 on 2024/9/29.
//

import SwiftUI
import Firebase // 确保导入 Firebase

@main
struct TestLoginApp: App {
    init() {
        FirebaseApp.configure() // 初始化 Firebase
    }
    
    var body: some Scene {
        WindowGroup {
            NavigationView {
                Login()
            }
        }
    }
}
