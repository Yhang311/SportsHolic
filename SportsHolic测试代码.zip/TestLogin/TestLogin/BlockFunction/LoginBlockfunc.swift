//
//  LoginBlockfunc.swift
//  TestLogin
//
//  Created by 杨航 on 2024/9/30.
//

import SwiftUI

struct LoginBlockfunc: View {
    let title:String
    @Binding var text:String
    
    init(title: String, text: Binding<String>) {
            self.title = title
            self._text = text
        }
    
    var body: some View {
        VStack{
            TextField(title, text: $text)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .autocapitalization(.none)
                .padding()
            
            Divider()
        }
    }
}

struct LoginBlockfunc_Previews: PreviewProvider {
    static var previews: some View {
        LoginBlockfunc(title: "title name", text: .constant(""))
    }
}
