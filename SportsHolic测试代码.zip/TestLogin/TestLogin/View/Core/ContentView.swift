//
//  ContentView.swift
//  TestLogin
//
//  Created by 杨航 on 2024/9/29.
//

import SwiftUI


struct ContentView: View {
    var body: some View {
        TabView {
            Home()
            .tabItem { // 第一个标签
                Label("Home", systemImage: "house")
            }
            
           Mypage()
                .tabItem { // 第二个标签
                    Label("Mypage", systemImage: "person")
                }
            Mypage()
                 .tabItem { // 第二个标签
                     Label("Mypage", systemImage: "person")
                 }
            Mypage()
                 .tabItem { // 第二个标签
                     Label("Mypage", systemImage: "person")
                 }
            Mypage()
                 .tabItem { // 第二个标签
                     Label("Mypage", systemImage: "person")
                 }
            
        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
