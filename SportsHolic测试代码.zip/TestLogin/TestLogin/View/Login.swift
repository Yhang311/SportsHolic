//
//  Login.swift
//  TestLogin
//
//  Created by 杨航 on 2024/9/29.
//

import SwiftUI
import Firebase
import FirebaseFirestore


struct Login: View {
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var fullName: String = ""
    @State private var supportedTeam: String = ""
    @State private var isRegistering: Bool = false
    @State private var errorMessage: String = ""
    @State private var isLoggedIn: Bool = false // 控制导航的状态

    var body: some View {
        NavigationStack {
            VStack {
                HStack{
                    Spacer()
                    Text("Sports Holic")
                        .font(.largeTitle)
                        .fontWeight(.thin)
                        .multilineTextAlignment(.leading)
                    Spacer()
                    Image(systemName: "person")
                    Text("My Page")
                        .fontWeight(.light)
                    Spacer()
                }
                
                LoginBlockfunc(title: "Email", text: $email)
                LoginBlockfunc(title: "Password", text: $password)
                
                if isRegistering {
                    LoginBlockfunc(title: "Full Name", text: $fullName)
                    LoginBlockfunc(title: "Supported Team", text: $supportedTeam)
                }
                
                Button(action: {
                    if isRegistering {
                        registerUser()   //isRegister 是True,说明在注册页面
                    } else {
                        loginUser()   //isRegister 是False，说明在登陆列表
                    }
                }) {
                    Text(isRegistering ? "Register" : "Login")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }     //用isRegister决定按钮信息
                
                Button(action: {
                    isRegistering.toggle()
                }) {
                    Text(isRegistering ? "Already have an account? Login" : "Don't have an account? Register")
                }
                
                Text(errorMessage)  //从下面函数中得到错误原因
                    .foregroundColor(.red)

                // 使用 NavigationLink 进行导航
                NavigationLink(destination: Mypage(), isActive: $isLoggedIn) {
                    EmptyView() // 隐藏的链接
                }
            }
            .padding()
        }
    }

    func loginUser() {   //用Auth登陆帐号
        Auth.auth().signIn(withEmail: email, password: password) { result, error in
            if let error = error {
                errorMessage = error.localizedDescription
            } else {
                print("login success") // 登录成功
                // 获取用户信息并导航到 Mypage
                loadUserDataAndNavigate()
            }
        }
    }

    func loadUserDataAndNavigate() {
        let db = Firestore.firestore()
        if let email = Auth.auth().currentUser?.email {
            db.collection("users").document(email).getDocument { document, error in
                if let document = document, document.exists {
                    let data = document.data()
                    let user = User(
                        email: email,
                        password: "", // 密码通常不需要存储
                        fullName: data?["fullName"] as? String ?? "",
                        supportedTeam: data?["supportedTeam"] as? String ?? ""
                    )
                    // 更新状态以导航到 Mypage
                    isLoggedIn = true
                    // 这里可以使用一个状态变量来传递用户信息
                    // 例如，使用 @State 或 @Binding
                } else {
                    errorMessage = error?.localizedDescription ?? "User data not found"
                }
            }
        }
    }

    func registerUser() {    //使用Auth注册账号
        Auth.auth().createUser(withEmail: email, password: password) { result, error in
            if let error = error {
                errorMessage = error.localizedDescription
            } else {
                // 注册成功，存储用户信息
                let user = User(email: email, password: password, fullName: fullName, supportedTeam: supportedTeam)
                saveUserToFirebase(user: user)
            }
        }
    }

    func saveUserToFirebase(user: User) {
        let db = Firestore.firestore()
        db.collection("users").document(user.email).setData([
            "fullName": user.fullName,
            "supportedTeam": user.supportedTeam
        ]) { error in
            if let error = error {
                errorMessage = error.localizedDescription
            } else {
                // 用户信息保存成功，导航到 MyPage
                print("User data saved successfully.")
            }
        }
    }
}

struct Login_Previews: PreviewProvider {
    static var previews: some View {
        Login()
    }
}
