//
//  SportHolicApp.swift
//  SportHolic
//
//  Created by 杨航 on 2024/9/28.
//

import SwiftUI
import Firebase

@main
struct SportHolicApp: App {
    @StateObject var viewModel = AuthModel()
    
    init(){
        FirebaseApp.configure()
    }
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(viewModel)
        }
    }
}
