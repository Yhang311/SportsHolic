//
//  AnalysisResult.swift
//  Sports_Holic
//
//  Created by 杨航 on 2024/9/28.
//

import SwiftUI

struct AnalysisResult: View {
    
    @State var Month  = ""
    
    var body: some View {
        
        NavigationStack {
            ZStack{
                Color.green
                    .ignoresSafeArea()
                VStack{
                    ScrollView{
                        VStack{
                            HStack{
                                Spacer()
                                Text("Sports Holic\n \nSchedule")
                                    .font(.largeTitle)
                                    .fontWeight(.black)
                                    .multilineTextAlignment(.leading)


                                Spacer()

                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)

                                Spacer()
                            }

                            HStack{
                                Spacer()
                                Button("News"){

                                }
                                .bold()
                                .foregroundColor(.white)
                                .frame(width: 100, height: 50)
                                .background(Color.black)
                                .cornerRadius(15)
                                Spacer()
                                Button("Schedule"){

                                }
                                .bold()
                                .foregroundColor(.white)
                                .frame(width: 100, height: 50)
                                .background(Color.black)
                                .cornerRadius(15)
                                Spacer()
                                Button("Analysis"){

                                }
                                .bold()
                                .foregroundColor(.white)
                                .frame(width: 100, height: 50)
                                .background(Color.black)
                                .cornerRadius(15)



                                Spacer()
                            }


                            Text("\n===========================\n")
                            Text("< 몇개월치 분석을 보시겠습니다? >")
                                .font(.title2)
                                .fontWeight(.bold)

                            HStack{
                                TextField("input the month", text: $Month)
                                    .padding(.all)
                                    .frame(width: 200, height: 50)
                                    .background(Color.white)
                                    .cornerRadius(15)
                                Text("개월")
                                    .font(.footnote)
                                    .fontWeight(.light)


                            }

                            Button("상대팀"){

                            }
                            .bold()
                            .foregroundColor(.white)
                            .frame(width: 230, height: 50)
                            .background(Color.gray)
                            .cornerRadius(15)

                            Text("\n")

                            Button("분석"){

                            }
                            .bold()
                            .foregroundColor(.white)
                            .frame(width: 230, height: 50)
                            .background(Color.black)
                            .cornerRadius(15)

                        }
                        
                        
                    }  //ScrollView
                    
                    Spacer()
                    
                    HStack {
                        NavigationLink(destination: Home()) {
                            VStack {
                                Image(systemName: "house")
                                Text("Home")
                            }
                        }
                        Spacer()
                        NavigationLink(destination: News()){
                            VStack {
                                Image(systemName: "newspaper")
                                Text("News")
                            }
                        }
                        Spacer()
                        NavigationLink(destination: Schedule()){
                            VStack {
                                Image(systemName: "timer")
                                Text("Schedule")
                            }
                        }
                        
                        Spacer()
                        NavigationLink(destination: Analysis()){
                            VStack {
                                Image(systemName: "x.squareroot")
                                Text("Analysis")
                            }
                        }
                       
                        Spacer()
                        NavigationLink(destination: Mypage()){
                            VStack {
                                Image(systemName: "person")
                                Text("Me")
                            }
                        }
                       
                        
                    }
                    .padding()
                    .background(Color.black)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    
                }  //Zstack
                .ignoresSafeArea(.keyboard, edges: .bottom)
            

                }
                
            
        }  //NavigationStack
        .navigationBarBackButtonHidden(true)

    }
}

struct AnalysisResult_Previews: PreviewProvider {
    static var previews: some View {
        AnalysisResult()
    }
}
