//
//  News.swift
//  Sports_Holic
//
//  Created by 杨航 on 2024/9/28.
//

import SwiftUI

struct News: View {
    var body: some View {
        NavigationStack {
            ZStack{
                Color.green
                    .ignoresSafeArea()
                VStack{
                    ScrollView{
                        VStack{
                            HStack{
                                Spacer()
                                Text("Sports Holic\n \nNEWS")
                                    .font(.largeTitle)
                                    .fontWeight(.black)
                                    .multilineTextAlignment(.leading)


                                Spacer()

                                Image("team1")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)

                                Spacer()
                            }

                            HStack{
                                Spacer()
                                Button("News"){

                                }
                                .bold()
                                .foregroundColor(.white)
                                .frame(width: 100, height: 50)
                                .background(Color.black)
                                .cornerRadius(15)
                                Spacer()
                                Button("Schedule"){

                                }
                                .bold()
                                .foregroundColor(.white)
                                .frame(width: 100, height: 50)
                                .background(Color.black)
                                .cornerRadius(15)
                                Spacer()
                                Button("Analysis"){

                                }
                                .bold()
                                .foregroundColor(.white)
                                .frame(width: 100, height: 50)
                                .background(Color.black)
                                .cornerRadius(15)



                            }



                            VStack{
                                Text("Hot KeyWord\n")
                                    .font(.title2)
                                    .foregroundColor(Color.red)
                                Text("1.XXXXXXXXX")
                                Text("2.XXXXXXXXX")
                                Text("3.XXXXXXXXX")
                            }

                            Spacer()

                            Text("===============================\n")

                            Text("NEWS")
                                .font(.title2)
                                .foregroundColor(Color.red)
                            Image("new1")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .padding(.all)
                            Button("XXXXXXX"){}


                        }
                        
                    }  //ScrollView
                    
                    Spacer()
                    
                    HStack {
                        NavigationLink(destination: Home()) {
                            VStack {
                                Image(systemName: "house")
                                Text("Home")
                            }
                        }
                        Spacer()
                        NavigationLink(destination: News()){
                            VStack {
                                Image(systemName: "newspaper")
                                Text("News")
                            }
                        }
                        Spacer()
                        NavigationLink(destination: Schedule()){
                            VStack {
                                Image(systemName: "timer")
                                Text("Schedule")
                            }
                        }
                        
                        Spacer()
                        NavigationLink(destination: Analysis()){
                            VStack {
                                Image(systemName: "x.squareroot")
                                Text("Analysis")
                            }
                        }
                       
                        Spacer()
                        NavigationLink(destination: Mypage()){
                            VStack {
                                Image(systemName: "person")
                                Text("Me")
                            }
                        }
                       
                        
                    }
                    .padding()
                    .background(Color.black)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    
                }  //Zstack
                .ignoresSafeArea(.keyboard, edges: .bottom)
            

                }
                
            
        }  //NavigationStack
        .navigationBarBackButtonHidden(true)

    }
}

struct News_Previews: PreviewProvider {
    static var previews: some View {
        News()
    }
}
