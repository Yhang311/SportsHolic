//
//  Register.swift
//  Sports_Holic
//
//  Created by 杨航 on 2024/9/28.
//

import SwiftUI

struct Register: View {
    @State var fullname = ""
    @State var Password = ""
    @State var email = ""
    @State var team = "teamA"
    @EnvironmentObject var viewModel : AuthModel
    
    @State var TeamSeclect = ""
//    let team = ["Ulsan Hyundai (울산 현대)",
//               "Jeonbuk Hyundai Motors (전북 현대 모터스)",
//               "Incheon United (인천 유나이티드)",
//               "FC Seoul (FC 서울)",
//               "Suwon FC (수원 FC)",
//               "Pohang Steelers (포항 스틸러스)" ,
//                "Jeju United (제주 유나이티드)",
//                "Daegu FC (대구 FC)",
//                "Gwangju FC (광주 FC)",
//                "Daejeon Hana Citizen (대전 하나 시티즌)"]
    
    var body: some View {
    
        NavigationStack{
            ZStack{
                Color.green
                    .ignoresSafeArea()
                
                VStack{
                    
                    Text("Sports Holic")
                        .font(.largeTitle)
                        .bold()
                        .padding()
                    
                    Spacer()
                    
                    Text("Register")
                        .font(.largeTitle)
                    
                    TextField("Email", text: $email)
                        .padding(.all)
                        .frame(width: 300, height: 50)
                        .background(Color.white)
                        .cornerRadius(15)
                        .autocapitalization(.none)
                    TextField("Full_name", text: $fullname)
                        .padding(.all)
                        .frame(width: 300, height: 50)
                        .background(Color.white)
                        .cornerRadius(15)
                    TextField("Password", text: $Password)
                        .padding(.all)
                        .frame(width: 300, height: 50)
                        .background(Color.white)
                        .cornerRadius(15)
                    

                    
                    
                    //跳转页面实现队伍选择
                    
//                    Button("Select Your Favorite Team "){
//
//                    }
//                    .bold()
//                    .foregroundColor(.white)
//                    .frame(width: 300, height: 50)
//                    .background(Color.black)
//                    .cornerRadius(15)
//
                    //注册
                    Button{
                        Task{
                            try await viewModel.createUser(withEmail:email,
                                                           password:Password,
                                                           fullname:fullname,
                                                           team:team)
                        }
                    }label: {
                        HStack{
                            Text("Register")
                                .fontWeight(.semibold)
                            Image(systemName: "arrow.right")
                        }
                        .bold()
                        .foregroundColor(.white)
                        .frame(width: 300, height: 50)
                        .background(Color.black)
                        .cornerRadius(15)
                        .padding()
                        .frame(width: UIScreen.main.bounds.width - 32,height: 48)
                    }
                    .padding(.all)
                    
                    Spacer()
                    //回到登陆
                    NavigationLink{
                        login()
                            .navigationBarBackButtonHidden(true)
                    }label: {
                        HStack{
                            Text("You have a account? ")
                                .foregroundColor(Color.black)
                            Text("Sign in!")
                                .foregroundColor(Color.white)
                                .fontWeight(.bold)
                        }
                        .font(.system(size: 14))
                    }
                    
                    
                }
                
            }
        }
            
        }
}

struct Register_Previews: PreviewProvider {
    static var previews: some View {
        Register()
    }
}
