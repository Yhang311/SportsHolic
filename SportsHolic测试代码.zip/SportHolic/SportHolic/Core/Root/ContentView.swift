//
//  ContentView.swift
//  SportHolic
//
//  Created by 杨航 on 2024/9/28.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var viewModel : AuthModel
    
    var body: some View {
        Group{
            if (viewModel.userSession != nil){
                Mypage()
            }else{
                login()
            }
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
